// WishMaker.in — shared site behaviour
document.addEventListener('DOMContentLoaded', function () {

  // Mobile nav toggle
  var toggle = document.querySelector('.nav-toggle');
  var nav = document.querySelector('.main-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      nav.classList.toggle('open');
    });
  }

  // Copy website link (sidebar share box)
  var copyBtn = document.getElementById('copyLinkBtn');
  if (copyBtn) {
    copyBtn.addEventListener('click', function () {
      var input = document.getElementById('shareLinkInput');
      input.select();
      input.setSelectionRange(0, 99999);
      navigator.clipboard && navigator.clipboard.writeText(input.value);
      copyBtn.textContent = 'Copied!';
      setTimeout(function () { copyBtn.textContent = 'Copy'; }, 1500);
    });
  }

  // Sidebar feedback mini form
  var fbForm = document.getElementById('sidebarFeedbackForm');
  if (fbForm) {
    fbForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var box = document.getElementById('sidebarFeedbackMsg');
      box.textContent = 'Thank you! Your feedback has been received.';
      fbForm.reset();
    });
  }

  // Category search filter (on homepage)
  var searchForm = document.getElementById('categorySearchForm');
  if (searchForm) {
    searchForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var q = document.getElementById('categorySearchInput').value.trim().toLowerCase();
      if (!q) return;
      var cards = document.querySelectorAll('.cat-card');
      var firstMatch = null;
      cards.forEach(function (card) {
        var name = card.getAttribute('data-name').toLowerCase();
        if (name.includes(q) && !firstMatch) firstMatch = card;
      });
      if (firstMatch) {
        firstMatch.scrollIntoView({ behavior: 'smooth', block: 'center' });
        firstMatch.style.boxShadow = '0 0 0 3px #D4AF37';
        setTimeout(function () { firstMatch.style.boxShadow = ''; }, 1800);
      } else {
        alert('No matching category found on this page. Try browsing all pages or a different keyword.');
      }
    });
  }

  // Contact form (contact-us page)
  var contactForm = document.getElementById('contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', function (e) {
      e.preventDefault();
      document.getElementById('contactFormMsg').textContent =
        'Thank you for reaching out! We will get back to you within 24-48 hours.';
      contactForm.reset();
    });
  }

  // Full feedback page form
  var feedbackPageForm = document.getElementById('feedbackPageForm');
  if (feedbackPageForm) {
    feedbackPageForm.addEventListener('submit', function (e) {
      e.preventDefault();
      document.getElementById('feedbackPageMsg').textContent =
        'Thank you for your valuable feedback! It helps us improve WishMaker.in.';
      feedbackPageForm.reset();
    });
  }

  // "Use this theme" buttons — placeholder action
  document.querySelectorAll('.use-theme-btn').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var themeName = btn.getAttribute('data-theme') || 'this theme';
      alert('"' + themeName + '" selected! Editor / checkout flow will open here.');
    });
  });

});
